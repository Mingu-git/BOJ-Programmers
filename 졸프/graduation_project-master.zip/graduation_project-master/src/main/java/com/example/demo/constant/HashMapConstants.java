package com.example.demo.constant;

import com.example.demo.domain.Consumer;

import java.util.HashMap;

public class HashMapConstants {

    public final HashMap<Long, Consumer> map = new HashMap<>();

}
