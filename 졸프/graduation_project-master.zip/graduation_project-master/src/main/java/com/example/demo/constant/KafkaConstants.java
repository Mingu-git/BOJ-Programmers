package com.example.demo.constant;

public class KafkaConstants {
    public static final String KAFKA_TOPIC = "quickstart-events";
    public static final String KAFKA_BROKER = "localhost:9092";
    public static final String GROUP_ID ="1";
    public static final String KAFKA_CONTAINER = "kafkaListenerContainerFactory";
}
